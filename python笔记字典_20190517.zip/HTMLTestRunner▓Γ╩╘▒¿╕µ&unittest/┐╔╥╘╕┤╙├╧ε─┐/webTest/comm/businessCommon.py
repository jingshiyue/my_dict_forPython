from selenium import webdriver
import time
import readConfig as readConfig

localReadConfig = readConfig.ReadConfig()


def is_exist():
    """
    Determine the element is exist
    :return:
    """

